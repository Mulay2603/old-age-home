(function($) {
  'use strict';
  $('.dropify').dropify();
})(jQuery);